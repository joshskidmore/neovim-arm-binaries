#!/usr/bin/env bash

echo "Installing runtime..."
sudo mkdir /usr/local/share/nvim
sudo rsync -ravP --delete ./runtime/ /usr/local/share/nvim/

echo -e "Installing nvim binary..."
sudo rsync -ravP ./bin/nvim /usr/local/bin/
